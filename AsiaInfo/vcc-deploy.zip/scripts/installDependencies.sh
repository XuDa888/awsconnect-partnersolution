#!/bin/bash

mkdir packages
cd packages
pip3 install boto3 --target .