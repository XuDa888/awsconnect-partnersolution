#!/bin/bash

source ../common/parameters.ini

# 发送HTTP请求到指定接口，并将响应存储到临时文件
response=$(curl --location --request POST "$VccOpenapiHost/enterprise/v1/save" \
--header 'Content-Type: application/json' \
--data '{
    "name": "'$InstanceName'",
    "instanceArn": "'$ConnectInstanceArn'",
    "assumeRoleArn": "'$ApiAccessRoleArn'",
    "s3Arn": "arn:aws:s3:::'$S3BucketName'"
}' 2>/dev/null)

# 检查HTTP请求是否成功
if [ $? -eq 0 ]; then
    # 使用jq工具从JSON响应中提取password字段的值
    VccUserPassword=$(echo "$response" | jq -r '.result.password')
    VccUserName=$(echo "$response" | jq -r '.result.user')
    VccApiAccessKey=$(echo "$response" | jq -r '.result.accessKey')
    VccApiSecretKey=$(echo "$response" | jq -r '.result.secretKey')
    enterpriseId=$(echo "$response" | jq -r '.result.enterpriseId')
    echo "开户成功,enterpriseId=$enterpriseId ,userName=$VccUserName, accessKey=$VccApiAccessKey"
    sed -i "s#^VccUserPassword.*#VccUserPassword=$VccUserPassword#" ../common/parameters.ini
    sed -i "s#^VccUserName.*#VccUserName=$VccUserName#" ../common/parameters.ini
    sed -i "s#^VccApiAccessKey.*#VccApiAccessKey=$VccApiAccessKey#" ../common/parameters.ini
    sed -i "s#^VccApiSecretKey.*#VccApiSecretKey=$VccApiSecretKey#" ../common/parameters.ini
else
    echo "HTTP请求失败"
fi
