#!/bin/bash

source ../common/parameters.ini
StackName=$Prefix-DeployS3
echo "StackName=${StackName}"

aws cloudformation deploy --template-file template.yml --stack-name $StackName \
    --parameter-overrides $(cat ../common/parameters.ini)

CfOutput=$(aws cloudformation describe-stacks --stack-name $StackName \
    --query Stacks[0].Outputs)
    
S3BucketName=$( echo $CfOutput | jq -r '.[] | select(.OutputKey | contains("S3Bucket"))? | .OutputValue' )

sed -i "s/^S3BucketName.*/S3BucketName=$S3BucketName/" ../common/parameters.ini