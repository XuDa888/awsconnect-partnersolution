#!/bin/bash

source ../common/parameters.ini

StackName=$Prefix-iamAssumeRole
ApiAccessRoleName=$Prefix-ApiAccess-$(date +%s)-$((1 + $RANDOM % 10000))
ApiAccessPolicyName=$Prefix-ApiAccess-$(date +%s)-$((1 + $RANDOM % 10000))

aws cloudformation deploy --template-file template.yml --stack-name $StackName \
    --parameter-overrides $(cat ../common/parameters.ini) \
    ApiAccessRoleName=${ApiAccessRoleName} \
    ApiAccessPolicyName=${ApiAccessPolicyName} \
    --capabilities CAPABILITY_NAMED_IAM

CfOutput=$(aws cloudformation describe-stacks --stack-name $StackName \
    --query Stacks[0].Outputs)
    
ApiAccessRoleArn=$( echo $CfOutput | jq -r '.[] | select(.OutputKey=="ApiAccessRole") | .OutputValue')

sed -i "s#^ApiAccessRoleArn.*#ApiAccessRoleArn=$ApiAccessRoleArn#" ../common/parameters.ini