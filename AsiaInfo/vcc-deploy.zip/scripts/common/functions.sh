#!/bin/bash

function PackageLambdaS3 () {
    LambdaName=$1
    
    ThisDir=$(pwd)
    cd ../../lambda
    
    # rm -f $LambdaName*.zip
    # zip -r $LambdaName.zip *
    CheckSum=($(md5sum $LambdaName.zip))
    LambdaZipFileWithCheckSum=$LambdaName-$CheckSum.zip
    aws s3 cp $LambdaName.zip s3://$S3BucketName/$LambdaBucketPath/$LambdaZipFileWithCheckSum
    
    cd $ThisDir
    
    eval "$2=$LambdaZipFileWithCheckSum"
}