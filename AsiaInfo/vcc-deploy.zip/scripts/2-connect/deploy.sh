#!/bin/bash

source ../common/parameters.ini

InstanceName=$Prefix-$(date +%s)-$((1 + $RANDOM % 10000))
StackName=$Prefix-Connect

aws cloudformation deploy --template-file template.yml --stack-name $StackName \
    --parameter-overrides $(cat ../common/parameters.ini) \
    InstanceName=$InstanceName \

CfOutput=$(aws cloudformation describe-stacks --stack-name $StackName \
    --query Stacks[0].Outputs)
    
ConnectInstanceArn=$( echo $CfOutput | jq -r '.[] | select(.OutputKey=="ConnectInstance") | .OutputValue')


sed -i "s#^ConnectInstanceArn.*#ConnectInstanceArn=$ConnectInstanceArn#" ../common/parameters.ini
sed -i "s#^InstanceName.*#InstanceName=$InstanceName#" ../common/parameters.ini