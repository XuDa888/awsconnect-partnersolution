#!/bin/bash

source ../common/functions.sh
source ../common/parameters.ini

returnValue=''
PackageLambdaS3 'vcc-modify-ctr' returnValue
ModifyCTRZip=$returnValue
echo "上传lambda zip文件，文件名:$ModifyCTRZip"

StackName=$Prefix-CtrPipeline

aws cloudformation deploy --template-file template.yml --stack-name $StackName \
    --parameter-overrides $(cat ../common/parameters.ini) \
    ModifyCtrLambdaKey=$LambdaBucketPath/$ModifyCTRZip \
    --capabilities CAPABILITY_NAMED_IAM

CfOutput=$(aws cloudformation describe-stacks --stack-name $StackName \
    --query Stacks[0].Outputs)
    
KinesisFirehoseArn=$( echo $CfOutput | jq -r '.[] | select(.OutputKey=="CTRDelivery") | .OutputValue')

sed -i "s#^KinesisFirehoseArn.*#KinesisFirehoseArn=$KinesisFirehoseArn#" ../common/parameters.ini